# LoFiCam

Aplikasi kamera Android bergaya retro ("0.3MP look"): foto otomatis diturunkan
resolusinya ke sekitar 0,3 megapiksel, dipiksel-kan (pixelated), diberi grain,
vignette, dan stempel tanggal — mirip kamera digital murah era 2000-an.

100% open source (lisensi MIT), dibuat dengan Kotlin + CameraX, **tanpa**
dependensi berbayar atau tertutup.

## Target perangkat
Dikonfigurasi khusus untuk **HP 64-bit dengan Android 13 (API 33)**:
- `minSdk = 33`, `targetSdk = 33` → hanya terpasang di Android 13 ke atas yang kompatibel API 33
- `abiFilters = arm64-v8a` → APK hanya berisi binary 64-bit, tidak termasuk 32-bit (armeabi-v7a/x86), ukuran APK lebih kecil

Kalau nanti mau dipasang juga di Android lebih lama, turunkan `minSdk` di
`app/build.gradle.kts`.

## Fitur
- Preview kamera langsung (CameraX)
- Efek downsample ke ~0,3MP + pixelation blok 4px
- Color grading ringan (kontras naik, sedikit hangat seperti sensor CCD lama)
- Film grain acak + vignette
- Stempel tanggal ala kamera digital jadul
- Simpan otomatis ke galeri (`Pictures/LoFiCam`)

## Cara build (butuh Android Studio, karena di sini tidak ada akses internet
untuk mengunduh Gradle/dependensi)

1. Install **Android Studio** (gratis): https://developer.android.com/studio
2. Buka folder project ini (`File > Open`), pilih folder `LoFiCam`.
3. Tunggu Gradle sync selesai (otomatis mengunduh dependensi CameraX, dll).
4. Hubungkan HP Android (aktifkan USB debugging) atau pakai emulator.
5. Klik tombol **Run ▶** — APK akan otomatis ter-build dan terpasang.
6. Untuk APK siap bagi/install manual: `Build > Build Bundle(s) / APK(s) > Build APK(s)`,
   hasilnya ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Struktur project
```
LoFiCam/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/lofi/cam/
│       │   ├── MainActivity.kt       # kamera, capture, simpan foto
│       │   └── LoFiProcessor.kt      # semua logika efek 0.3MP
│       └── res/
│           ├── layout/activity_main.xml
│           ├── drawable/shutter_button.xml
│           └── values/ (strings, colors, themes)
├── build.gradle.kts
└── settings.gradle.kts
```

## Mengubah tingkat "lo-fi"
Semua parameter efek ada di `LoFiProcessor.kt`:
- `TARGET_MEGAPIXELS` — ubah untuk resolusi lebih besar/kecil dari 0,3MP
- `PIXELATE_BLOCK` — ukuran blok piksel (makin besar makin kasar)
- fungsi `addGrain(amount = ...)` — jumlah noise film grain
- fungsi `stampDate` — bisa dihapus/diganti formatnya, atau dimatikan lewat
  `LoFiProcessor.process(bitmap, stampTimestamp = false)`

## Lisensi
MIT — bebas dipakai, diubah, dan dibagikan kembali, termasuk untuk keperluan
komersial, selama menyertakan notice lisensi aslinya.
